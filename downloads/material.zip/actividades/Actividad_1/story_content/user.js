function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6k8ZR2AEk6p":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

